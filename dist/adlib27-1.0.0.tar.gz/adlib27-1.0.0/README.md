[![Build Status](https://travis-ci.org/ad-lib27/cs207-FinalProject.svg?branch=master)](https://travis-ci.org/ad-lib27/cs207-FinalProject.svg?branch=master)

[![Coverage Status](https://codecov.io/gh/ad-lib27/cs207-FinalProject/branch/master/graph/badge.svg)](https://codecov.io/gh/ad-lib27/cs207-FinalProject)


# cs207-FinalProject

Group Number: 27

Group Members: 
  - Rodrigo Daboin Sanchez
  - Jerri Zhang
  - Camille Bean
  - Mark Gakman
